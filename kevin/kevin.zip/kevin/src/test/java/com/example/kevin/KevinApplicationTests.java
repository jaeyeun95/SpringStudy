package com.example.kevin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KevinApplicationTests {

	@Test
	void contextLoads() {
	}

}
